# Data Sources

This file should describe access to all the raw data required to reproduce the project and instructions on setting up the `data/` folder. Provide publicly accessible download links to your files (GDrive, S3 buckets, etc.)