# Source Code

Describe the additional code created for the project which may include:

- scripts to automate data loading and processing,
- scripts to train and evaluate models,
- applications to demo your data science solution, such as a `Flask` or `streamlit` app.